# Me Diz Um

Pacote feito para o trabalho final da disciplina Programação Orientada a Objetos II.

Este pacote gera dados simples aleatóriamente. 

Para utilizar é necessário ter instalado as bibliotecas:
- pandas 
- pillow.

<br>

## Categorias presentes:
- Nomes
- Idade 
- Peso
- Altura
- Paises
- Estados (do Brasil)
- Cidades (do Brasil)
- Cores
- Imagem
- Arquivo
- CPF
- RG
- Produtos
- Signos
- Dias da Semana
- Meses
- Datas de Nascimento


<br>



## Exemplos de uso:

```
from medizum import diz
diz = diz()
print(diz.nome())
print(diz.idade())
print(f'Oi, me chamo {diz.nome()} e tenho {diz.idade()}!')
```




<br>
